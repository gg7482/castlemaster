#!/bin/bash

./stop-cloudark.sh

./start-cloudark.sh
